
#ifndef LCD_H_
#define LCD_H_

#include <avr/io.h>						/* Include AVR std. library file */

#define lcd_data_dir DDRB				/* Define LCD data port direction */
#define lcd_command_dir DDRC				/* Define LCD command port direction register */
#define lcd_data_port PORTB				/* Define LCD data port */
#define lcd_command_port PORTC				/* Define LCD data port */
#define rs PC0							/* Define Register Select (data reg./command reg.) signal pin */
#define rw PC1							/* Define Read/Write signal pin */
#define en PC2							/* Define Enable signal pin */



void lcd_command (unsigned char);		/* LCD command write function */
void lcd_data (unsigned char);			/* LCD data write function */
void lcd_init (void);					/* LCD Initialize function */
void lcd_string (unsigned char*);		/* Send string to LCD function */
void clear_LCD();                              /*clear lcd*/


#endif /* LCD_H_ */